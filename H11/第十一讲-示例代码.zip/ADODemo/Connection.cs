﻿namespace ADODemo
{
    internal class Connection
    {
    }
}